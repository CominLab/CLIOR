#CLIOR

#Installation
##Download CLIOR
[CLIOR](https://bitbucket.org/samu661/clior/downloads/CLIOR_v1.tar.gz)  

##Compilation:
Open terminal and go to CLIOR/Release/ and then:  
make all  

#Algorithm Option
In the following paragraph is described the input file's structure and the parameters available in the CLIOR algorithm.  

##File accepted and structure
In the following paragraph is described the input file's structure.  
CLIOR to execute correctly needs two kind of file, one in which reads are divided into groups and another in which reads are classified.  
  
For groups file the structure is the following:  
> READ_IDENTIFICATION,GROUP  
  
To obtain this file call MetaProb with -mg option, and if possible use paired-end files.
  
For classification file the structure is the following:  
> READ_IDENTIFICATION,Length,Class <first line is a colums description line>  
> READ_IDENTIFICATION,Length,Class (first read)  
  
To obtain this file use Clark-l algorithm, or other software and convert the output in this format.  
ATTENTION: First line is a identification line with 3 colums in that order  
  
##Parameter
**-si** File paths of groups and classification for single-end dataset. Ex. -si pathgroups pathclass  
**-pi** File paths of groups and classification for paired-end dataset. Ex. -pi pathgroups1 pathclass1 pathgroups2 pathclass2  
**-dirOutput** Path directory output files. Default: output/  

#Run
CLIOR needs to compute groups and classification of read datasets in a certain structure of file (**See** file accepted and structure). You need to download two software which can do this without translate outputs and these are MetaProb and Clark.  
  
Calls algorithm where is compiled:  
./CLIOR -si pathfilegroups/example.groups.csv pathfileclass/example.csv  
./CLIOR -pi pathfilegroups/example1.groups.csv pathfileclass/example1.csv pathfilegroups/example2.groups.csv pathfileclass/example2.csv  
./CLIOR -pi pathfilegroups/example1.groups.csv pathfileclass/example1.csv pathfilegroups/example2.groups.csv pathfileclass/example2.csv  

##Download MetaProb
[MetaProb](https://bitbucket.org/samu661/metaprob/overview)  

##Download Clark
[Clark](http://clark.cs.ucr.edu/Tool/)  
